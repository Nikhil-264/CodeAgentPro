"""
Pipeline Orchestrator
Wires all agents into the full self-repair loop:
  Plan → Generate → Execute → Test → [Debug loop] → Refactor → Done
"""
import asyncio
from typing import AsyncGenerator
from core.llm_client import OllamaClient
from core.sandbox import ExecutionSandbox
from agents.planner import PlannerAgent
from agents.code_generator import CodeGeneratorAgent
from agents.test_generator import TestGeneratorAgent
from agents.debugger import DebuggerAgent
from agents.refactor import RefactorAgent


class AgentPipeline:
    MAX_DEBUG_ATTEMPTS = 5

    def __init__(self, model: str = "deepseek-coder:6.7b"):
        llm = OllamaClient(model=model)
        self.planner = PlannerAgent(llm)
        self.coder = CodeGeneratorAgent(llm)
        self.tester = TestGeneratorAgent(llm)
        self.debugger = DebuggerAgent(llm, max_attempts=self.MAX_DEBUG_ATTEMPTS)
        self.refactor = RefactorAgent(llm)
        self.sandbox = ExecutionSandbox()

    async def run(
        self,
        task: str,
        language: str = "Python",
        framework: str = "standard library",
        skip_tests: bool = False,
        skip_refactor: bool = False,
    ) -> AsyncGenerator[dict, None]:
        """
        Run the full pipeline, yielding step events so the frontend
        can stream real-time progress.

        Each yielded dict has shape:
            {
                "step": str,          # agent name / phase
                "status": str,        # "running" | "success" | "failed"
                "data": dict,         # step-specific payload
            }
        """
        steps = []

        # ── Step 1: Plan ──────────────────────────────────────────────────
        yield {"step": "Planner", "status": "running", "data": {}}
        plan_result = await self.planner.run(task)
        yield {"step": "Planner", "status": "success" if plan_result["success"] else "warning",
               "data": plan_result}
        steps.append({"agent": "Planner", "result": plan_result})

        # ── Step 2: Generate code ─────────────────────────────────────────
        yield {"step": "CodeGenerator", "status": "running", "data": {}}
        gen_result = await self.coder.run(task, language=language, framework=framework)

        if not gen_result["success"]:
            yield {"step": "CodeGenerator", "status": "failed", "data": gen_result}
            return

        yield {"step": "CodeGenerator", "status": "success", "data": gen_result}
        current_code = gen_result["code"]
        steps.append({"agent": "CodeGenerator", "result": gen_result})

        # ── Step 3: Execute code in sandbox ───────────────────────────────
        yield {"step": "Sandbox", "status": "running", "data": {"phase": "initial_run"}}
        exec_result = await self.sandbox.run_code(current_code)
        yield {"step": "Sandbox", "status": "success" if exec_result["success"] else "warning",
               "data": exec_result}

        if skip_tests:
            yield {"step": "Pipeline", "status": "success",
                   "data": {"final_code": current_code, "steps": steps}}
            return

        # ── Step 4: Generate tests ────────────────────────────────────────
        yield {"step": "TestGenerator", "status": "running", "data": {}}
        test_result = await self.tester.run(current_code, task)

        if not test_result["success"]:
            yield {"step": "TestGenerator", "status": "failed", "data": test_result}
            yield {"step": "Pipeline", "status": "partial",
                   "data": {"final_code": current_code, "steps": steps,
                             "note": "Tests could not be generated"}}
            return

        yield {"step": "TestGenerator", "status": "success", "data": test_result}
        test_code = test_result["test_code"]

        # ── Step 5: Self-repair debug loop ────────────────────────────────
        for attempt in range(1, self.MAX_DEBUG_ATTEMPTS + 1):
            yield {"step": "Sandbox", "status": "running",
                   "data": {"phase": "test_run", "attempt": attempt}}
            test_exec = await self.sandbox.run_tests(current_code, test_code)
            yield {"step": "Sandbox", "status": "success" if test_exec["success"] else "warning",
                   "data": {**test_exec, "attempt": attempt}}

            if test_exec["success"]:
                # All tests passed — exit the loop
                yield {"step": "DebugLoop", "status": "success",
                       "data": {"attempts": attempt, "message": "All tests passed!"}}
                break

            if attempt == self.MAX_DEBUG_ATTEMPTS:
                yield {"step": "DebugLoop", "status": "failed",
                       "data": {"attempts": attempt,
                                 "message": "Max debug attempts reached",
                                 "last_error": test_exec["stderr"] or test_exec["stdout"]}}
                break

            # Tests failed → ask the debugger to fix it
            error_output = test_exec["stdout"] + "\n" + test_exec["stderr"]
            yield {"step": "Debugger", "status": "running",
                   "data": {"attempt": attempt}}
            debug_result = await self.debugger.run(current_code, error_output, attempt)
            yield {"step": "Debugger", "status": "success" if debug_result["success"] else "warning",
                   "data": debug_result}

            current_code = debug_result["fixed_code"]

        # ── Step 6: Refactor (only if tests passed) ───────────────────────
        if not skip_refactor and test_exec.get("success"):
            yield {"step": "Refactor", "status": "running", "data": {}}
            refactor_result = await self.refactor.run(current_code)
            yield {"step": "Refactor",
                   "status": "success" if refactor_result["success"] else "warning",
                   "data": refactor_result}
            current_code = refactor_result["refactored_code"]

        # ── Done ──────────────────────────────────────────────────────────
        yield {
            "step": "Pipeline",
            "status": "success",
            "data": {
                "final_code": current_code,
                "test_code": test_code,
                "steps": steps,
            }
        }
